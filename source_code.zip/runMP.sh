source ../assignment-env/bin/activate
python train.py config/train_shakespeare_char.py --n_gpus=$1